let question = 0; 
let score = 0;
let home;
let gif1;
let gif2;
let gif3;


let gif5;
let attempts = 0
let timer = 0
let dividedscore = 0
let finalScore = 0

function preload()
{
  home = loadImage ('assets/New Piskel.gif');
  gif1 = loadImage ('assets/New Piskel clone.gif');
  gif2 = loadImage ('assets/New Piskel clone clone.gif');
  gif3 = loadImage ('assets/b.gif');
  gif5= loadImage ('assets/smile.gif');
}
function setup() {
  createCanvas(500, 500);
}
function draw() {
  background(220);
  image(home,0,0, width, height);
  fill('white')
  textFont('Orbitron')
  textSize(30);
  
  fill(0,100,200)
  strokeWeight(4);
  stroke(100);
  square(375, 50, 120, 20, 15, 10, 5);
  fill(100,0,400)
  rect(375,30,120,40,20)
  noStroke();
  fill('white')
  text("Score: ", 380, 60);
  textSize(90);
  text(score, 400,150)
  textSize(30)
  fill ('Yellow')
  text(timer, 15, 35);
  textSize(15)
  text("Time", 10, 60)
  fill ('Red')
  text("Attempts", 85, 60)
  textSize(90)
  fill('white')
  textSize(30)
  fill ('red')
  text(attempts, 90, 35);
  textSize(90)
  fill('white')
  
  if (frameCount % 60 == 0 && timer > -1 && question > 0 && question < 11) { 
    timer ++;
  }

  
  if (question == 0) {
    
    textSize(30);
    text("Welcome to this game!", 80, 250); 
    text("Click anywhere to start", 67, 400)
  }
  
  else if (question == 1) {
    
    image(gif1, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400,150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(20);
    text("Q1: Who was Prime Minister in 2006?", 80, 250);
    
    text("A: Gordon Brown", 100, 300);
    text("B: David Cameron", 100, 350);
  }
 
  else if (question == 2) {

    image(gif2, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)  
    fill('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(20);
    text("Q2: What is the capital of Spain?", 100 , 250);
    
    text("A: Barcelona", 100, 300)
    text("B: Madrid", 100, 350)

  }
  
  else if (question == 3) {
    
    image(gif3, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(20);
    text("Q3: What is the capital of France?", 100 , 250);
    
    text("A: Nice", 100, 300)
    text("B: Leon", 100, 350)
    text("C: Paris", 300, 300)

  }
  
  else if (question == 4) {
    
    image(gif1, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(20);
    text("Q4: Helsinki is the capital city of which", 50 , 230);
    text("country?", 200, 260)
    
    text("A: Norway", 100, 300)
    text("B: Denmark", 100, 350)
    text("C: Germany", 300, 300)
    text("D: Finland", 300, 350)
    
  }
  else if (question == 5) {
    
    image(gif2, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(18);
    text("Q5: What is another name for 'Saccharide'?", 50 , 230);
    
    text("A: Sugar", 100, 300)
    text("B: Fat", 100, 350)
    text("C: Protein", 300, 300)
    text("D: Sodium", 300, 350)
    
  }

    else if (question == 6) {
    
    image(gif3, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(18);
    text("Q6: Who is the richest man in the world?", 50 , 230);
    
    text("A: Bill Gates", 100, 300)
    text("B: Jeff Bezos", 100, 350)
    text("C: Kylie Jenner", 300, 300)
    text("D: Elon Musk", 300, 350)
    
  }

    else if (question == 7) {
    
    image(gif1, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(20);
    text("Q7: When was YouTube created?", 50 , 230);
    
    text("A: 2004", 100, 300)
    text("B: 2005", 100, 350)
    text("C: 2006", 300, 300)
    text("D: 2007", 300, 350)
    
  }
  
  else if (question == 8) {
    
    image(gif2, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(18);
    text("Q8: What does the 'A' in 'DEFRA' stand for?", 50 , 230);

    
    text("A: Agency", 100, 300)
    text("B: Association", 100, 350)
    text("C: Affairs", 300, 300)
    text("D: Activity", 300, 350)
    
  }

  else if (question == 9) {
    
    image(gif3, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(30);
    text("Q9: What is 123 x 456?", 50 , 230);

    textSize(20);
    text("A: 56782", 100, 300)
    text("B: 98980", 100, 350)
    text("C: 56088", 300, 300)
    text("D: 20216", 300, 350)
    text("E: 46952", 200, 400)
    
  }

  else if (question == 10) {
    
    image(gif1, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    text("Score: ", 380, 60);
    textSize(90);
    text(score, 400, 150)
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(18);
    text("Q10: What was the answer to question 5?", 50 , 230);
    
    text("A: A", 100, 300)
    text("B: B", 100, 350)
    text("C: C", 300, 300)
    text("D: D", 300, 350)
    
  }
  else if (question == 11) {
    
    dividedscore = score / attempts
    finalScore = round(dividedscore * 100)
    if (score == 0) {
      finalScore = 0
    }

    image(home, 0, 0, width, height)
    textSize(30);
    fill(0,100,200)
    strokeWeight(4);
    stroke(100);
    square(375, 50, 120, 20, 15, 10, 5);
    fill(100,0,400)
    rect(375,30,120,40,20)
    noStroke();
    fill('white')
    textSize(30)
    fill ('Yellow')
    text(timer, 15, 35);
    textSize(15)
    text("Time", 10, 60)
    fill ('Red')
    text("Attempts", 85, 60)
    textSize(90)
    fill ('white')
    textSize(30)
    fill ('red')
    text(attempts, 90, 35);
    textSize(90)
    fill('white')
    
    textSize(30)

    fill(0,150,150)
    text("Final Score: ", 140, 100);
    textSize(70);
    text(finalScore, 198,190)
    textSize(25)
    text("%", 245, 220)
    fill('white')

    text("You scored", 130, 280)
    fill('Yellow')
    text(score, 300,280)
    fill('white')
    text("/10!", 335, 280)
    text("In", 140,318)
    fill('Yellow')
    text(timer, 180, 318)
    fill('White')
    text("seconds!!", 220,318 )
    text("And it took", 100, 375)
    fill('red')
    text(attempts, 265, 375 )
    fill('white')
    text('attempts', 305, 375)
    textSize(15)
    text('Press r or click anywhere to restart', 115, 400)
    textSize(25)
    
    
         
  }

}
function mousePressed() {
    question += 1;  
  if (question == 12) {
    question = 0;
    attempts = 0;
    timer = 0;
    score = 0;
    
  }
    
 
    
}
function keyPressed() {
  
  if (question == 1 && key == 'a'){
    score += 1;
    question += 1;
  }
  if (question == 2 && key == 'b'){
    score += 1;
    question += 1;
  }
  if (question == 1 && key !== 'a'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 2 && key !== 'b'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 3 && key == 'c'){
    score += 1;
    question += 1;
  }
  if (question == 3 && key !== 'c'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 4 && key == 'd'){
    score += 1;
    question += 1;
  }
  if (question == 4 && key !== 'd'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 5 && key == 'a'){
    score += 1;
    question += 1;
  }
  if (question == 5 && key !== 'a'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 6 && key == 'd'){
    score += 1;
    question += 1;
  }
  if (question == 6 && key !== 'd'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 7 && key == 'b'){
    score += 1;
    question += 1;
  }
  if (question == 7 && key !== 'b'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 8 && key == 'c'){
    score += 1;
    question += 1;
  }
  if (question == 8 && key !== 'c'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 9 && key == 'c'){
    score += 1;
    question += 1;
    attempts +=1;
  }
  if (question == 9 && key !== 'c'){
    attempts += 1;
    console.log(attempts)
  }
  if (question == 10 && key == 'a'){
    score += 1;
    question += 1;
    attempts += 1;
  }
  if (question == 10 && key !== 'a'){
    attempts += 1;
    console.log(attempts)
  }
  
  if (question == 11 && key == 'r'){
    question += 1;
  }

  if (question == 12){
    question = 0;
    attempts = 0;
    timer = 0;
    score = 0;
    
  }
}